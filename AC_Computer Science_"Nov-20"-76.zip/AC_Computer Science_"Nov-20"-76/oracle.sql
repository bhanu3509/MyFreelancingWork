
CREATE TABLE Customer
(
  Customer_ID     VARCHAR NOT NULL,
  Customer_Name   VARCHAR,
  Customer_Mobile VARCHAR,
  CONSTRAINT PK_Customer PRIMARY KEY (Customer_ID)
);

CREATE TABLE Farmer
(
  FarmerID     BIGINT  NOT NULL,
  FarmerName   VARCHAR,
  FarmName     VARCHAR,
  FarmLocation VARCHAR,
  CONSTRAINT PK_Farmer PRIMARY KEY (FarmerID)
);

CREATE TABLE ProductType
(
  ProdTypeID   BIGINT  NOT NULL,
  ProdTypeName VARCHAR,
  CONSTRAINT PK_ProductType PRIMARY KEY (ProdTypeID)
);

CREATE TABLE Enterprise
(
  ARN_ID   VARCHAR NOT NULL,
  FarmerID BIGINT ,
  CONSTRAINT PK_Enterprise PRIMARY KEY (ARN_ID)
);

CREATE TABLE Produce
(
  ProduceID   BIGINT  NOT NULL,
  ProduceName VARCHAR,
  ProdTypeID  BIGINT  NOT NULL,
  FarmerID    BIGINT  NOT NULL,
  CONSTRAINT PK_Produce PRIMARY KEY (ProduceID, ProdTypeID, FarmerID)
);

CREATE TABLE Products
(
  ProductID              NOT NULL,
  Weight         DECIMAL,
  Metric         VARCHAR,
  PricePerWeight DECIMAL,
  ProduceID      BIGINT  NOT NULL,
  CONSTRAINT PK_Products PRIMARY KEY (ProductID, ProduceID)
);

CREATE TABLE Orders
(
  Order_ID    VARCHAR NOT NULL,
  Order_Total         NOT NULL,
  Customer_ID VARCHAR,
  CONSTRAINT PK_Orders PRIMARY KEY (Order_ID, Order_Total)
);

CREATE TABLE Payment
(
  Payment_ID          NOT NULL,
  Order_ID    VARCHAR NOT NULL,
  Order_Total         NOT NULL,
  CONSTRAINT PK_Payment PRIMARY KEY (Payment_ID, Order_ID, Order_Total)
);

ALTER TABLE Products
  ADD CONSTRAINT FK_Produce_TO_Products
    FOREIGN KEY (ProduceID)
    REFERENCES Produce (ProduceID);

ALTER TABLE Produce
  ADD CONSTRAINT FK_ProductType_TO_Produce
    FOREIGN KEY (ProdTypeID)
    REFERENCES ProductType (ProdTypeID);

ALTER TABLE Enterprise
  ADD CONSTRAINT FK_Farmer_TO_Enterprise
    FOREIGN KEY (FarmerID)
    REFERENCES Farmer (FarmerID);

ALTER TABLE Produce
  ADD CONSTRAINT FK_Farmer_TO_Produce
    FOREIGN KEY (FarmerID)
    REFERENCES Farmer (FarmerID);

ALTER TABLE Orders
  ADD CONSTRAINT FK_Customer_TO_Orders
    FOREIGN KEY (Customer_ID)
    REFERENCES Customer (Customer_ID);

ALTER TABLE Payment
  ADD CONSTRAINT FK_Orders_TO_Payment
    FOREIGN KEY (Order_ID, Order_Total)
    REFERENCES Orders (Order_ID, Order_Total);

